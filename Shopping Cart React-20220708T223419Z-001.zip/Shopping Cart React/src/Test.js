export default function Basket(props) {
  return <div className="basket">basket</div>;
}
