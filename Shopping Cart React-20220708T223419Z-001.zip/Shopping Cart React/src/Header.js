export default function Header(props) {
  return (
    <header>
      <div>
        <a className="title" href="#/">
          Your shopping cart
        </a>
      </div>
      <div>
        <a href="#/cart">Cart</a>
        <a href="#/signin">SignIn</a>
      </div>
    </header>
  );
}
