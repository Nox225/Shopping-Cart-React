export default function Product(props) {
  const { product, onAdd } = props;
  return (
    <div>
      <img className="image" src={product.image} alt={product.name} />
      <h3 className="name">{product.name}</h3>
      <div>${product.price}</div>
      <button onClick={() => onAdd(product)} className="add-btn">
        Add To Cart
      </button>
    </div>
  );
}
