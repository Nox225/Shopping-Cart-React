import Product from "./Product.js";

export default function Main(props) {
  const { products, onAdd } = props;
  return (
    <div className="main">
      <div className="basket-title">Products</div>
      {products.map((product) => (
        <Product key={product.id} product={product} onAdd={onAdd} />
      ))}
    </div>
  );
}
