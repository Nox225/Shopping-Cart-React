import Product from "./Product";

export default function Basket(props) {
  const { cartItems, onAdd, onRemove } = props;
  const itemsPrice = cartItems.reduce((a, c) => a + c.price * c.qty, 0);
  const taxPrice = itemsPrice * 0.14;
  const shippingPrice = itemsPrice > 2000 ? 0 : 50;
  const totalPrice = itemsPrice + taxPrice + shippingPrice;
  return (
    <div className="basket">
      <div className="basket-title">Cart Items</div>
      <div>
        {cartItems.length === 0 && (
          <div className="cart-empty">Cart Is Empty</div>
        )}
      </div>
      {cartItems.map((item) => (
        <>
          <div className="row-3">
            <div key={item.id} className="item-name">
              <div className="col-2">{item.name}</div>
            </div>
            <div className="col-2">
              <button className="add" onClick={() => onAdd(item)}>
                +
              </button>
              <button className="remove" onClick={() => onRemove(item)}>
                -
              </button>
            </div>
            <div className="col-2">
              {item.qty} x ${item.price.toFixed(2)}
            </div>
          </div>
        </>
      ))}
      {cartItems.length !== 0 && (
        <>
          <hr className="line"></hr>
          <div className="row">
            <div className="col-2">Items Price</div>
            <div className="col-1">${itemsPrice.toFixed(2)}</div>
          </div>
          <div className="row">
            <div className="col-2">Tax Price</div>
            <div className="col-1">${taxPrice.toFixed(2)}</div>
          </div>
          <div className="row">
            <div className="col-2">Shipping Price</div>
            <div className="col-1">${shippingPrice.toFixed(2)}</div>
          </div>
          <div className="row">
            <div className="col-2">
              <strong>Total Price</strong>
            </div>
            <div className="col-1">
              <strong>${totalPrice.toFixed(2)}</strong>
            </div>
          </div>
        </>
      )}
      <button className="add-btn checkout">Checkout</button>
    </div>
  );
}
